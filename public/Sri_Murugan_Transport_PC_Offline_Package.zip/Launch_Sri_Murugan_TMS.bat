@echo off
chcp 65001 >nul
title Sri Murugan Transport - TMS Desktop Offline
echo ============================================================
echo   SRI MURUGAN TRANSPORT - OFFLINE PC DESKTOP APP
echo   100%% Local Disk Storage - No Cloud / No Internet Required
echo ============================================================
echo.
echo Launching Sri Murugan Transport in standalone desktop window...
echo.

where msedge >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" msedge --app="%~dp0index.html" --allow-file-access-from-files
    exit
)

where chrome >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" chrome --app="%~dp0index.html" --allow-file-access-from-files
    exit
)

start "" "%~dp0index.html"
exit
