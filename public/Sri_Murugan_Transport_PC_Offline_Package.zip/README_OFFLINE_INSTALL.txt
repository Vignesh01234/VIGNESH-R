============================================================
SRI MURUGAN TRANSPORT - OFFLINE PC DESKTOP APPLICATION
============================================================

Thank you for downloading Sri Murugan Transport Management System.
This edition runs 100% OFFLINE on your local computer disk with NO internet connection.

QUICK START INSTRUCTIONS:
-------------------------
1. Extract all files from this ZIP to a folder on your computer (e.g. C:\SriMuruganTMS or Desktop).
2. Double-click "Launch_Sri_Murugan_TMS.bat" to start the app in a clean desktop window.
3. Or double-click "Sri_Murugan_Transport_Offline_Desktop_App.html" to run directly in any web browser.
4. You can right-click "Launch_Sri_Murugan_TMS.bat" -> "Send to" -> "Desktop (create shortcut)" to create an app icon on your Windows desktop.

LOGIN CREDENTIALS (OFFLINE ACCESS):
-----------------------------------
- Administrator: Username: admin | Password: admin (or PIN: 1234)
- Booking Staff: Username: staff1 | Password: staff (or PIN: 1234)
- Accountant:    Username: accounts | Password: accounts (or PIN: 1234)
- Guest Viewer:  Username: viewer | Password: viewer (or PIN: 1234)

LOCAL DISK STORAGE & BACKUP:
----------------------------
- All Lorry Receipts (LRs), Parties, Vehicles, Drivers, and Payments are saved directly on your PC disk.
- You can export a backup JSON file anytime using the "Local Disk Backup" button or when exiting.
- If you ever switch computers, use "Restore Backup" to import your data instantly.
